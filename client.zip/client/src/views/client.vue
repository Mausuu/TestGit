<template>
    <p>this iss cliennnt</p>
    
    <router-view/>
</template>