<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Order extends Model
{
    use HasFactory;
  
    public $timestamps=false;//set time to false
    protected $fillable=['id','id_user','diachinguoinhan','trangthai','thanhtoan','sdt','id_product','product_qty'];
    protected $primaryKey='id';
    protected $table='order';

  
}
